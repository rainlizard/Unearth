To set an image for a custom object, add a png to this directory with a filename that matches the name of the object. Case-insensitive and spaces are treated the same as underscores.

Add "_portrait" onto the end of the filename for a separate image to be used in the Thing selection window.